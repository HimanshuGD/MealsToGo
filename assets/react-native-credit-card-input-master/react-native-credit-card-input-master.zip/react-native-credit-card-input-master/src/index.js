import connectToState from "./connectToState";
import LiteCCF from "./LiteCreditCardInput";

export const LiteCreditCardInput = connectToState(LiteCCF);
